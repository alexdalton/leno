#include "scene.h"
#include "input_file.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/* Apparently ANSI C99 refuses to provide math constants:
   http://ubuntuforums.org/showthread.php?t=583094 */
#ifndef M_PI
    #define M_PI 3.14159265358979323846
#endif
#ifndef M_SQRT1_2
    #define M_SQRT1_2 0.70710678118654752440
#endif

bool parse_angle (char ** cursor, float * radians_out);
bool parse_vector (char ** cursor, vector * vector_out);
bool parse_normal (char ** cursor, vector * normal_out);
bool parse_resolution (char ** cursor, resolution * resolution_out);
int parse_camera (char ** cursor, camera * camera_out);
int parse_background (char ** cursor, color * background_color_out);
int parse_frustum (char ** cursor, surface * surface_out);
int parse_circle (char ** cursor, surface * surface_out);

static int tests_run;
static int tests_passed;

bool approx_equal (float expected, float actual)
{
    const float max_error = 1e-4;
    if (actual < max_error)
    {
        return fabs(expected - actual) < max_error;
    }
    else
    {
        float relative_error = fabs(expected - actual) / fabs(actual);
        return relative_error < max_error;
    }
}

void test_float (char * label, float expected, float actual)
{
    if (approx_equal(expected, actual))
    {
        /*printf("Pass: %s: %f ~= %f\n", label, expected, actual);*/
        tests_passed++;
    }
    else
    {
        /*printf("Fail: %s: expected %f, got %f\n", label, expected, actual);*/
    }
    tests_run++;
}

void test_direction (char * label, direction expected, direction actual)
{
    if ((expected.theta-actual.theta)<0.001 && (expected.phi- actual.phi)<0.001)
    {
        /*printf("Pass: %s: (theta:%f, phi:%f) = (theta:%f, phi:%f)\n",
               label, expected.theta, expected.phi, actual.theta, actual.phi);*/
        tests_passed++;
    }
    else
    {
       /* printf("Fail: %s: expected (theta:%f, phi:%f), got (theta:%f, phi:%f)\n",
               label, expected.theta, expected.phi, actual.theta, actual.phi);*/
    }
    tests_run++;
}

void test_resolution (char * label, resolution expected, resolution actual)
{
    if (expected.width == actual.width && expected.height == actual.height)
    {
        /*printf("Pass: %s: (width:%d, height:%d) = (width:%d, height:%d)\n",
               label, expected.width, expected.height, actual.width, actual.height);*/
        tests_passed++;
    }
    else
    {
        /*printf("Fail: %s: expected (width:%d, height:%d), got (width:%d, height:%d)\n",
               label, expected.width, expected.height, actual.width, actual.height);*/
    }
    tests_run++;
}

void test_vector (char * label, vector expected, vector actual)
{
    if (approx_equal(expected.x, actual.x) &&
        approx_equal(expected.y, actual.y) &&
        approx_equal(expected.z, actual.z))
    {
        /*printf("Pass: %s: (x:%f, y:%f, z:%f) ~= (x:%f, y:%f, z:%f)\n", label,
               expected.x, expected.y, expected.z, actual.x, actual.y, actual.z);*/
        tests_passed++;
    }
    else
    {
        /*printf("Fail: %s: expected (x:%f, y:%f, z:%f), got (x:%f, y:%f, z:%f)\n", label,
               expected.x, expected.y, expected.z, actual.x, actual.y, actual.z);*/
    }
    tests_run++;
}

void test_color (char * label, color expected, color actual)
{
    if (approx_equal(expected.r, actual.r) &&
        approx_equal(expected.g, actual.g) &&
        approx_equal(expected.b, actual.b))
    {
        /*printf("Pass: %s: (r:%f, g:%f, b:%f) ~= (r:%f, g:%f, b:%f)\n", label,
               expected.r, expected.g, expected.b, actual.r, actual.g, actual.b);*/
        tests_passed++;
    }
    else
    {
        /*printf("Fail: %s: expected (r:%f, g:%f, b:%f), got (r:%f, g:%f, b:%f)\n", label,
               expected.r, expected.g, expected.b, actual.r, actual.g, actual.b);*/
    }
    tests_run++;
}

void test_parse_angle ()
{
    char string1[] = "(60, 40)";
    char string2[] = "-30";
    /*test if parse_angle can parse "60"*/
    char * cursor = &string1[1];
    float radians;
    parse_angle(&cursor, &radians);
    test_float("Angle test 1", 2.0f * M_PI / 6.0f, radians);
    /*test if parse_angle can parse "-30"*/
    cursor = string2;
    parse_angle(&cursor, &radians);
    test_float("Angle test 2", -M_PI / 6.0f, radians);
}

void test_parse_vector ()
{
    char string1[] = "(2,3,4)";
    char string2[] = "(-15,2e-4,0.0)";
    char * cursor = string1;
    vector result;
    parse_vector(&cursor, &result);
    test_vector("Vector test 1", (vector){2, 3, 4}, result);
    
    cursor = string2;
    parse_vector(&cursor, &result);
    test_vector("Vector test 2", (vector){-15, 2e-4f, 0.0}, result);
}

void test_parse_normal ()
{
    char string1[] = "(0, 1, 0)";
    char string2[] = "(-1, 1, 0)";
    
    char * cursor = string1;
    vector result;
    parse_normal(&cursor, &result);
    test_vector("Normal test 1", (vector){0, 1, 0}, result);

    cursor = string2;
    parse_normal(&cursor, &result);
    test_vector("Normal test 2", (vector){-M_SQRT1_2, M_SQRT1_2, 0}, result);
}

void test_parse_resolution ()
{
    char string[] = "(641, 481)";
    char * cursor = string;
    resolution result;
    resolution expected = {641, 481};
    
    parse_resolution(&cursor, &result);
    test_resolution("Resolution test", expected, result);
}

void test_parse_camera ()
{
    char string[] = "camera position:(2,3,4) direction:(45, -20) view_angle:90 resolution:(801,601)";
    char * cursor = &string[6];
    camera result;

    parse_camera(&cursor, &result);

    test_vector("Camera position", (vector){2,3,4}, result.position);
    test_float("Camera direction theta", M_PI / 4.0f, result.direction.theta);
    test_float("Camera direction phi", -M_PI / 9.0f, result.direction.phi);
    test_float("Camera view angle", M_PI / 2.0f, result.view_angle);
    test_resolution("Camera resolution", (resolution){801, 601}, result.resolution);
}

void test_parse_background ()
{
    char string[] = "background color:(0.1, 0.4, 1.0)";
    char * cursor = &string[10];
    color result;
    
    parse_background(&cursor, &result);

    test_color("Background color", (color){0.1, 0.4, 1.0}, result);
}

void test_parse_frustum ()
{
    char string[] = "frustum centers:((-10, 0, 10), (20, 10, 10)) radii:(0, 30) "
                    "diffuse:(0.0, 0.9, 0.4) specular:(0.0, 0.1, 0.05) refraction_index:1.2";
    char * cursor = &string[7];
    surface result;
    frustum * geometry = (frustum *)&result.geometry;
    
    parse_frustum(&cursor, &result);
    
    test_vector("Frustum center 0", (vector){-10,  0, 10}, geometry->centers[0]);
    test_vector("Frustum center 1", (vector){ 20, 10, 10}, geometry->centers[1]);
    test_float("Frustum radius 0", 0, geometry->radii[0]);
    test_float("Frustum radius 1", 30, geometry->radii[1]);
    test_color("Frustum diffuse color", (color){0.0, 0.9, 0.4}, result.diffuse_part);
    test_color("Frustum specular color", (color){0.0, 0.1, 0.05}, result.specular_part);
    test_float("Frustum refraction index", 1.2, result.refraction_index);
}

void test_parse_circle ()
{
    char string[] = "circle center:(1, 0, 0) radius:39 normal:(0, -4, 0) "
                    "diffuse:(0.3, 0.0, 0.0) specular:(0.5, 0.0, 0.0) refraction_index:0.9";
    char * cursor = &string[6];
    surface result;
    circle * geometry = (circle *)&result.geometry;

    parse_circle(&cursor, &result);
    
    test_vector("Circle center", (vector){1, 0, 0}, geometry->center);
    test_vector("Circle normal", (vector){0, -1, 0}, geometry->normal);
    test_float("Circle radius", 39, geometry->radius);
    test_color("Circle diffuse color", (color){0.3, 0.0, 0.0}, result.diffuse_part);
    test_color("Circle specular color", (color){0.5, 0.0, 0.0}, result.specular_part);
    test_float("Circle refraction index", 0.9, result.refraction_index);
}

void test_scene(char * filename)
{
    FILE * scene_file;
    
    scene_file = fopen(filename, "r");
    if (scene_file == NULL)
    {
        printf("Unable to open input scene file %s Load Scene tests not run!\n",filename);
        return;
    }
    scene cur_scene = {};
    
    if (load_scene(scene_file, &cur_scene))
    {
        printf("Scene Load Returned Error\n");
        return;
    }
    /*test camera*/
    test_vector("Scene Camera Position", (vector){-21, 0, 9}, cur_scene.camera.position);
    test_float("Scene Camera Angle", M_PI/4.0f, cur_scene.camera.view_angle);
    test_direction("Scene Camera Direction", (direction){0, - M_PI / 4.0f}, cur_scene.camera.direction);
    test_resolution("Scene Camera Resolution", (resolution){961,321}, cur_scene.camera.resolution);
    /*test background*/
    test_color("Scene Background Color", (color){0.2,0.3,0.2}, cur_scene.background_color); 
    /*test light 1 color*/
    test_color("Scene Light 1 Color", (color){0.7,0.6,0.6}, cur_scene.light_sources[0].color);
    /*test light 2 position*/
    test_vector("Scene Light 2 Position", (vector){-9, 5, 8}, cur_scene.light_sources[1].position);
    /*test surface 1 Diffuse*/
    test_color("Scene Surface 1 Diffuse", (color){0.7, 0.6, 0.6},cur_scene.surfaces[0].diffuse_part);
    /*test surface 3 Specular*/
    test_color("Scene Surface 2 Specular", (color){1.1, 1.0, 0.6},cur_scene.surfaces[2].specular_part);
    fclose(scene_file);
    free(cur_scene.light_sources);
    free(cur_scene.surfaces);
}

typedef void test_function();

int main (int argc, char *argv[])
{
    tests_run = tests_passed = 0;

    if (argc < 2)
    {
        fprintf(stderr, "Usage: %s <test_num>\n", argv[0]);
        return -1;
    }

    const int num_functions = 6;
    int test_num = atoi(argv[1]);
    if (test_num < 0 || test_num >= num_functions)
    {
        fprintf(stderr, "Invalid test number\n");
        return -1;
    }
    test_function * test_functions[] =
    {
        test_parse_angle,
        test_parse_normal,
        test_parse_resolution,
        test_parse_camera,
        test_parse_background,
    };
    tests_run = tests_passed = 0;
    if(test_num>=0 && test_num<5){
    	test_functions[test_num]();
    }
    if(test_num==5){
        if(argc!=3){
		printf("Enter a file please \n");
		return 0;
    	}
	test_scene(argv[2]);
    }/*scores for each function*/
    int scores[6]={5,5,5,15,15,20};
    printf("Score: %d, %d out of %d tests passed.\n ",(int)(scores[test_num]*(float)tests_passed/tests_run), tests_passed, tests_run);
    if (tests_passed == tests_run)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}
