#include "scene.h"
#include "input_file.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

/* Apparently ANSI C99 refuses to provide math constants:
   http://ubuntuforums.org/showthread.php?t=583094 */
#ifndef M_PI
    #define M_PI 3.14159265358979323846
#endif
#ifndef M_SQRT1_2
    #define M_SQRT1_2 0.70710678118654752440
#endif

bool parse_angle (char ** cursor, float * radians_out);
bool parse_vector (char ** cursor, vector * vector_out);
bool parse_normal (char ** cursor, vector * normal_out);
bool parse_resolution (char ** cursor, resolution * resolution_out);
int parse_camera (char ** cursor, camera * camera_out);
int parse_background (char ** cursor, color * background_color_out);
int parse_frustum (char ** cursor, surface * surface_out);
int parse_circle (char ** cursor, surface * surface_out);

static int tests_run;
static int tests_passed;

bool approx_equal (float expected, float actual)
{
    const float max_error = 1e-4;
    if (actual < max_error)
    {
        return fabs(expected - actual) < max_error;
    }
    else
    {
        float relative_error = fabs(expected - actual) / fabs(actual);
        return relative_error < max_error;
    }
}

void test_float (char * label, float expected, float actual)
{
    if (approx_equal(expected, actual))
    {
        /*printf("Pass: %s: %f ~= %f\n", label, expected, actual);*/
        tests_passed++;
    }
    else
    {
        /*printf("Fail: %s: expected %f, got %f\n", label, expected, actual);*/
    }
    tests_run++;
}

void test_direction (char * label, direction expected, direction actual)
{
    if ((expected.theta-actual.theta)<0.001 && (expected.phi- actual.phi)<0.001)
    {
        /*printf("Pass: %s: (theta:%f, phi:%f) = (theta:%f, phi:%f)\n",
               label, expected.theta, expected.phi, actual.theta, actual.phi);*/
        tests_passed++;
    }
    else
    {
       /* printf("Fail: %s: expected (theta:%f, phi:%f), got (theta:%f, phi:%f)\n",
               label, expected.theta, expected.phi, actual.theta, actual.phi);*/
    }
    tests_run++;
}

void test_resolution (char * label, resolution expected, resolution actual)
{
    if (expected.width == actual.width && expected.height == actual.height)
    {
        /*printf("Pass: %s: (width:%d, height:%d) = (width:%d, height:%d)\n",
               label, expected.width, expected.height, actual.width, actual.height);*/
        tests_passed++;
    }
    else
    {
        /*printf("Fail: %s: expected (width:%d, height:%d), got (width:%d, height:%d)\n",
               label, expected.width, expected.height, actual.width, actual.height);*/
    }
    tests_run++;
}

void test_vector (char * label, vector expected, vector actual)
{
    if (approx_equal(expected.x, actual.x) &&
        approx_equal(expected.y, actual.y) &&
        approx_equal(expected.z, actual.z))
    {
        /*printf("Pass: %s: (x:%f, y:%f, z:%f) ~= (x:%f, y:%f, z:%f)\n", label,
               expected.x, expected.y, expected.z, actual.x, actual.y, actual.z);*/
        tests_passed++;
    }
    else
    {
        /*printf("Fail: %s: expected (x:%f, y:%f, z:%f), got (x:%f, y:%f, z:%f)\n", label,
               expected.x, expected.y, expected.z, actual.x, actual.y, actual.z);*/
    }
    tests_run++;
}

void test_color (char * label, color expected, color actual)
{
    if (approx_equal(expected.r, actual.r) &&
        approx_equal(expected.g, actual.g) &&
        approx_equal(expected.b, actual.b))
    {
        /*printf("Pass: %s: (r:%f, g:%f, b:%f) ~= (r:%f, g:%f, b:%f)\n", label,
               expected.r, expected.g, expected.b, actual.r, actual.g, actual.b);*/
        tests_passed++;
    }
    else
    {
        /*printf("Fail: %s: expected (r:%f, g:%f, b:%f), got (r:%f, g:%f, b:%f)\n", label,
               expected.r, expected.g, expected.b, actual.r, actual.g, actual.b);*/
    }
    tests_run++;
}

void test_parse_angle ()
{
    char string1[] = "-30";
    char string2[] = "-185";
    char * cursor = string1;
    float radians;
    bool correct = parse_angle(&cursor, &radians);
    if (approx_equal(-M_PI / 6.0f, radians))
    {
	cursor = string2;
	bool incorrect = parse_angle(&cursor, &radians);
        if(incorrect==false && correct==true){
        	tests_passed++;}
    }
    tests_run++;
}

void test_parse_vector ()
{
    char string1[] = "(2,3,4)";
    char string2[] = "(-15,2e-4,0.0)";
    char * cursor = string1;
    vector result;
    parse_vector(&cursor, &result);
    test_vector("Vector test 1", (vector){2, 3, 4}, result);
    
    cursor = string2;
    parse_vector(&cursor, &result);
    test_vector("Vector test 2", (vector){-15, 2e-4f, 0.0}, result);
}

void test_parse_normal ()
{
    char string1[] = "(0, 0, 0)";
    
    char * cursor = string1;
    vector result;
    bool incorrect = parse_normal(&cursor, &result);
    if(incorrect==false){
	tests_passed++;}
    tests_run++;	
}

void test_parse_resolution ()
{
    char string[] = "(-641, 481)";
    char * cursor = string;
    resolution result;
    bool incorrect = parse_resolution(&cursor, &result);
    if(incorrect==false){
    	tests_passed++;
    }
    tests_run++;
}

void test_parse_camera ()
{
    char string[] = "camera position:(2,3,4) unknown:40 direction:(45, -20) view_angle:90 resolution:(801,601)";
    char * cursor = &string[6];
    camera result;
    char buf[256];
    setbuf(stderr, buf);
    parse_camera(&cursor, &result);
    if(strcmp("Camera Parsing Error\n",buf)==0){
	tests_passed++;}
    tests_run++;
    fflush(stderr);
}

void test_parse_background ()
{
    char string[] = "background color:(0.1, 0.4, 1.0)";
    char * cursor = &string[10];
    color result;
    parse_background(&cursor, &result);

    test_color("Background color", (color){0.1, 0.4, 1.0}, result);
}

void test_parse_frustum ()
{
    char string[] = "frustum centers:((-10, 0, 10), (20, 10, 10)) radii:(0, 30) "
                    "diffuse:(0.0, 0.9, 0.4) specular:(0.0, 0.1, 0.05) refraction_index:1.2";
    char * cursor = &string[7];
    surface result;
    frustum * geometry = (frustum *)&result.geometry;
    
    parse_frustum(&cursor, &result);
    
    test_vector("Frustum center 0", (vector){-10,  0, 10}, geometry->centers[0]);
    test_vector("Frustum center 1", (vector){ 20, 10, 10}, geometry->centers[1]);
    test_float("Frustum radius 0", 0, geometry->radii[0]);
    test_float("Frustum radius 1", 30, geometry->radii[1]);
    test_color("Frustum diffuse color", (color){0.0, 0.9, 0.4}, result.diffuse_part);
    test_color("Frustum specular color", (color){0.0, 0.1, 0.05}, result.specular_part);
    test_float("Frustum refraction index", 1.2, result.refraction_index);
}

void test_parse_circle ()
{
    char string[] = "circle center:(1, 0, 0) radius:39 normal:(0, -4, 0) "
                    "diffuse:(0.3, 0.0, 0.0) specular:(0.5, 0.0, 0.0) refraction_index:0.9";
    char * cursor = &string[6];
    surface result;
    circle * geometry = (circle *)&result.geometry;

    parse_circle(&cursor, &result);
    
    test_vector("Circle center", (vector){1, 0, 0}, geometry->center);
    test_vector("Circle normal", (vector){0, -1, 0}, geometry->normal);
    test_float("Circle radius", 39, geometry->radius);
    test_color("Circle diffuse color", (color){0.3, 0.0, 0.0}, result.diffuse_part);
    test_color("Circle specular color", (color){0.5, 0.0, 0.0}, result.specular_part);
    test_float("Circle refraction index", 0.9, result.refraction_index);
}

void test_scene(char * filenamegood,char *filenamebad)
{
    FILE * scene_file;
    FILE * bad_scene_file;
    
    scene_file = fopen(filenamegood, "r");
    bad_scene_file = fopen(filenamebad,"r");
    if (scene_file == NULL || bad_scene_file==NULL)
    {
        printf("Unable to open input scenes %s and %s Load Scene tests not run!\n",filenamegood,filenamebad);
        return;
    }
    scene cur_scene = {};
    
    int outgood = load_scene(scene_file, &cur_scene);
    scene bad_scene = {};
    int outbad = load_scene(bad_scene_file, &bad_scene);
    if(outgood==0 && outbad ==-1)
	tests_passed++;
    tests_run++;
    fclose(scene_file);
    fclose(bad_scene_file);
    free(cur_scene.light_sources);
    free(cur_scene.surfaces);
}

typedef void test_function();

int main (int argc, char *argv[])
{
    tests_run = tests_passed = 0;

    if (argc < 2)
    {
        fprintf(stderr, "Usage: %s <test_num>\n", argv[0]);
        return -1;
    }

    const int num_functions = 5;
    int test_num = atoi(argv[1]);
    if (test_num < 0 || test_num >= num_functions)
    {
        fprintf(stderr, "Invalid test number\n");
        return -1;
    }
    test_function * test_functions[] =
    {
        test_parse_angle,
        test_parse_normal,
        test_parse_resolution,
        test_parse_camera,
    };
    tests_run = tests_passed = 0;
    if(test_num>=0 && test_num<4){
    	test_functions[test_num]();
    }
    if(test_num==4){
        if(argc!=4){
		printf("Enter two file please \n");
		return 0;
    	}
	test_scene(argv[2],argv[3]);
    }/*scores for each function*/
    int scores[5]={4,4,4,4,4};
    printf("Score: %d, %d out of %d tests passed.\n ",(int)(scores[test_num]*(float)tests_passed/tests_run), tests_passed, tests_run);
    if (tests_passed == tests_run)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}
