#include "maze.h"


int countSurroundingPath(maze_t * maze, int x, int y)
{
    int left = 0, right = 0, down = 0, up = 0;
    if ((x - 1) >= 0)
    {
        left = (maze->cells[y][x - 1] == PATH) || (maze->cells[y][x - 1] == START) || (maze->cells[y][x - 1] == END);
    }
    if ((x + 1) < width)
    {
        right = (maze->cells[y][x + 1] == PATH) || (maze->cells[y][x + 1] == START) || (maze->cells[y][x + 1] == END);
    }
    if ((y - 1) >= 0)
    {
        down = (maze->cells[y - 1][x] == PATH) || (maze->cells[y - 1][x] == START) || (maze->cells[y - 1][x] == END);
    }
    if ((y + 1) < height)
    {
        up = (maze->cells[y + 1][x] == PATH) || (maze->cells[y + 1][x] == START) || (maze->cells[y + 1][x] == END);
    }
    return left + right + down + up;
}

int checkMaze(maze_t * maze)
{
    int i, j;
    for (i = 0; i < maze->height; i++)
    {
        for (j = 0; j < maze->width; j++)
        {
            if (maze->cells[i][j] == START || maze->cells[i][j] == END) {
                if (countSurroundingPath(maze, j, i) != 1)
                    return 0;
            }
            if (maze->cells[i][j] == PATH) {
                if (countSurroundingPath(maze, j, i) != 2)
                    return 0;
            }
        }
    }
    return 1;
}
