#include <stdio.h>
#include <stdlib.h>
#include "maze.h"
#include "solutionChecker.h"

void freeMaze(char ** maze, int height);
 
int main(int argc, char **argv)
{
    // attempt to open input file
    if (argc < 2)
    {
        printf("You need a valid input maze file.\n");
        return -1;
    }
    in = fopen(argv[1], "r");
    if (in == NULL)
    {
        printf("Could not open file: %s\n", argv[1]);
        return -1;
    }

    printf("Creating maze with file %s\n", argv[1]);
    maze_t maze = createMaze(argv[1]);

    printf("Unsolved maze:\n");
    printMaze(maze);

    if(solveMazeManhattanDFS(maze, maze->startColumn, maze->startRow))
    {
        printf("Solved maze:\n");
        printMaze(maze);
        if(checkMaze(maze))
        {
            printf("Solution to maze is valid\n");
        }
        else
        {
            printf("Incorrect solution to maze\n");
        }
    }
    else
    {
        printf("Maze is unsolvable\n");
    }

    printf("Destroying maze\n");

    destroyMaze(maze);
 
    return 0;
}
