#include "game_test.h"


game * _make_game(int rows, int cols)
/*! Create an instance of a game structure with the given number of rows
    and columns, initializing elements to 0 and return a pointer
    to it. (See game.h for the specification for the game data structure) 
    The needed memory should be dynamically allocated with the malloc family
    of functions.

    Note that the calloc function is useful for allocating and zeroing
    memory in one call (see "calloc" man page)
*/
{
	
    game * mygame = malloc(sizeof(game));
	
    mygame->rows = rows;
    mygame->cols = cols;
	mygame->score = 0;

    mygame->cells = malloc(rows*cols*sizeof(cell));

	cell * cell_ptr = mygame->cells;
	int i;
	
	for(i = 0; i < rows*cols ; i++){
		*cell_ptr = -1;
		cell_ptr++;
	}
	
    return mygame;
	
	//return NULL;
}

void _remake_game(game ** _cur_game_ptr,int new_rows,int new_cols)
/*! Given a game structure that is passed by reference, change the
	game structure to have the given number of rows and columns. Initialize
	the score and all elements in the cells to zero. Make sure that any 
	memory previously allocated is not lost in this function.	
*/
{
	free((*_cur_game_ptr)->cells);
	
	(*_cur_game_ptr)->rows = new_rows;
	(*_cur_game_ptr)->score = 0;
	(*_cur_game_ptr)->cols = new_cols;
	(*_cur_game_ptr)->cells = malloc(new_rows*new_cols*sizeof(cell));
	
	cell * cell_ptr = (*_cur_game_ptr)->cells;
	int i;
	
	for(i = 0; i < new_rows*new_cols ; i++){
		*cell_ptr = -1;
		cell_ptr++;
	}
	
}

void _destroy_game(game * cur_game)
/*! Deallocate any memory acquired with malloc associated with the given game instance.
    This includes any substructures the game data structure contains. */
{
    free(cur_game->cells);
    free(cur_game);
    cur_game = NULL;
    return;
}

cell * _get_cell(game * cur_game, int row, int col)
/*! Given a game, a row, and a column, return a pointer to the corresponding
    cell on the game. (See game.h for game data structure specification)
    This function should be handy for accessing game cells.
*/
{
    if( row >= 0 && row < cur_game->rows && col >= 0 && col < cur_game->cols ){

        cell * cell_ptr;
        cell_ptr = cur_game -> cells;
        cell_ptr += col + (row * cur_game->cols); /*get cell pointer */
     
        return cell_ptr; /*return cell pointer*/
    }
    else
        return NULL;
}

int _move_w(game * cur_game){
/*!Slides all of the tiles in cur_game upwards. If a tile matches with the one above it, the tiles are merged 
   by adding their values together. Additionally, a tile can not merge twice in one turn. If sliding the tiles
   up does not cause any cell to change value, w is an invalid move and return 0. Otherwise, return 1.
*/
    int retval = 0;
    cell * current_cell, *open_cell;
    int i,j, open_ind;
    for(j = 0; j < cur_game->cols; j++){ //work on each column
        open_ind = 0;	//open_ind is the first cell in the current column which a tile can "move" into. It can be occupied or empty. Initially the 0th cell is always open.
        for(i = 1; i < cur_game->rows; i++){     //look at each element in the column iteratively. We can ignore the 0th because it cannot move.
            current_cell = get_cell(cur_game,i,j);  
            open_cell = get_cell(cur_game,open_ind,j);

            if(*current_cell != -1){

                if(*open_cell == -1){ //the open_cell is empty.
                    *open_cell = *current_cell;
                    *current_cell = -1; // Slide current_cell up to open_cell. This tile hasn't merged yet so this cell is now still open, but occupied.
                    retval = 1; 
                }
                else if(*open_cell == *current_cell){ //the open cell is occupied and matching
                    *open_cell = *current_cell+*open_cell; 
                    *current_cell = -1; //merge the two cells together by adding their values.
                    open_ind++;  //open_cell is no longer open, so the next cell down in the column is now the first open cell.
                    retval = 1;
					cur_game->score += *open_cell; //increase score for matching two tiles.
                }
                else{ //the open cell is occupied and does not match.
                    open_ind++; //next cell down is now the new open_cell
                    open_cell = get_cell(cur_game,open_ind,j); 
                    if(open_cell != current_cell){                    
                        *open_cell = *current_cell;
                        *current_cell = -1;
                        retval = 1;
                    }
                }           
            }
        }
    }
    return retval;
};

int _move_s(game * cur_game){ //slide down
    int retval = 0;
    cell * current_cell, *open_cell;
    int i,j, open_ind;
    for(j = 0; j < cur_game->cols; j++){ //for every column
        open_ind = cur_game->rows-1;
        for(i = cur_game->rows-2; i >= 0; i--){     
            current_cell = get_cell(cur_game,i,j);
            open_cell = get_cell(cur_game,open_ind,j);

            if(*current_cell != -1){

                if(*open_cell == -1){
                    *open_cell = *current_cell;
                    *current_cell = -1;
                    retval = 1;
                }
                else if(*open_cell == *current_cell){
                    *open_cell = *current_cell+*open_cell;
                    *current_cell = -1;
                    open_ind--;
                    retval = 1; 
					cur_game->score += *open_cell;
                }
                else{
                    open_ind--;
                    open_cell = get_cell(cur_game,open_ind,j);
                    if(open_cell != current_cell){                    
                        *open_cell = *current_cell;
                        *current_cell = -1;
                        retval = 1;
                    }
                }           
            }
        }
    }
    return retval;
};

int _move_a(game * cur_game){ //slide to the left
    int retval = 0;
    cell * current_cell, *open_cell;
    int i,j, open_ind;
    for(i = 0; i < cur_game->rows; i++){ //for every column
        open_ind = 0;
        for(j = 1; j < cur_game->cols; j++){ //sweep from left

            current_cell = get_cell(cur_game,i,j);
            open_cell = get_cell(cur_game,i,open_ind);

            if(*current_cell != -1){

                if(*open_cell == -1){
                    *open_cell = *current_cell;
                    *current_cell = -1;
                    retval = 1;

                }
                else if(*open_cell == *current_cell){
                    *open_cell = *current_cell+*open_cell;
                    *current_cell = -1;
                    open_ind++; 
                    retval = 1;
					cur_game->score += *open_cell;
                }
                else{
                    open_ind++;
                    open_cell = get_cell(cur_game,i,open_ind);
                    if(open_cell != current_cell){                    
                        *open_cell = *current_cell;
                        *current_cell = -1;
                        retval = 1;
                    }
                }           
            }
        }
    }
    return retval;
};

int _move_d(game * cur_game){ //slide to the right
    int retval = 0;
    cell * current_cell, *open_cell;
    int i,j, open_ind;
    for(i = 0; i < cur_game->rows; i++){ //for every column
        open_ind = cur_game->cols-1;
        for(j = cur_game->cols-2; j >= 0; j--){     
            current_cell = get_cell(cur_game,i,j);
            open_cell = get_cell(cur_game,i,open_ind);

            if(*current_cell != -1){

                if(*open_cell == -1){
                    *open_cell = *current_cell;
                    *current_cell = -1;
                    retval = 1;
                }
                else if(*open_cell == *current_cell){
                    *open_cell = *current_cell+*open_cell;
                    *current_cell = -1;
                    open_ind--; 
                    retval = 1;
					cur_game->score += *open_cell;
                }
                else{
                    open_ind--;
                    open_cell = get_cell(cur_game,i,open_ind);
                    if(open_cell != current_cell){                    
                        *open_cell = *current_cell;
                        *current_cell = -1;
                        retval = 1;
                    }
                }           
            }
        }
    }
    return retval;
};

int _legal_move_check(game * cur_game)
/*! Given the current game check if there are any legal moves on the board. There are
    no legal moves if sliding in any direction will not cause the game to change.
	Return 1 if there are possible legal moves, 0 if there are none.
 */
{

    int i,j;
    cell * main_ptr, *n1, *n2, *n3, *n4;
    for(i = 0; i < cur_game->rows; i++){
        for(j = 0; j < cur_game->cols; j++){
            main_ptr = get_cell(cur_game,i,j);
            n1 = get_cell(cur_game,i,j-1);
            n2 = get_cell(cur_game,i-1,j);
            n3 = get_cell(cur_game,i+1,j);
            n4 = get_cell(cur_game,i,j+1);

            if(n1 != NULL)
                if(*n1 == *main_ptr || *n1 == -1)
                    return 1;

            if(n2 != NULL)
                if(*n2 == *main_ptr || *n2 == -1)
                    return 1;

            if(n3 != NULL)
                if(*n3 == *main_ptr || *n3 == -1)
                    return 1;

            if(n4 != NULL)
                if(*n4 == *main_ptr || *n4 == -1)
                    return 1;    
        }
    }
    return 0;
}


