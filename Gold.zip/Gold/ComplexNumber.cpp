#include "ComplexNumber.h"

//Empty Constructor initializes a complex number with value 0+0i
//Do not forget to set inherited variables (NumberType)
ComplexNumber::ComplexNumber(){
	realComponent = 0;
	imagComponent = 0;
	NumberType = COMPLEX;
}

//Constructor initializes a complex number with provided real and imag values
//Do not forget to set inherited variables (NumberType)
ComplexNumber::ComplexNumber(double real, double imag){
	realComponent = real;
	imagComponent = imag;
	NumberType = COMPLEX;
}

//Copy constructer copies values from provided reference to other ComplexNumber
ComplexNumber::ComplexNumber( const ComplexNumber& other ){
	realComponent = other.get_realComponent();
	imagComponent = other.get_imagComponent();
	NumberType = other.get_NumberType();
}

//Set the value of realComponent
void ComplexNumber::set_realComponent(double rval){
	realComponent = rval;
}

//Set the value of imagComponent
void ComplexNumber::set_imagComponent(double ival){
	imagComponent = ival;
}

//Get the value of realComponent
double ComplexNumber::get_realComponent(void) const{
	return realComponent;
}

//Get the value of imagComponent
double ComplexNumber::get_imagComponent(void) const{
	return imagComponent;
}

//set the values of both realComponent and imagComponent
void ComplexNumber::set_value (double rval, double ival)
{
    //code here
    realComponent = rval;
    imagComponent = ival;
}

//return the magnitude of the complex number
double ComplexNumber::magnitude(){
    //code here
    return sqrt(pow(realComponent,2)+pow(imagComponent,2));
}

//imag + imag
ComplexNumber ComplexNumber::operator + (const ComplexNumber& arg)
{
    ComplexNumber result = ComplexNumber();
    result.set_realComponent(realComponent + arg.get_realComponent());
    result.set_imagComponent(imagComponent + arg.get_imagComponent());
    return result;
}

//imag - imag
ComplexNumber ComplexNumber::operator - (const ComplexNumber& arg)
{
    //code here
    ComplexNumber result = ComplexNumber();
    result.set_realComponent(realComponent - arg.get_realComponent());
    result.set_imagComponent(imagComponent - arg.get_imagComponent());
    return result;
}

//imag * imag
ComplexNumber ComplexNumber::operator * (const ComplexNumber& arg)
{
    //code here
    ComplexNumber result = ComplexNumber();
    result.set_realComponent(realComponent * arg.get_realComponent() - imagComponent * arg.get_imagComponent());
    result.set_imagComponent(imagComponent * arg.get_realComponent() + realComponent * arg.get_imagComponent());
    return result;
}

//imag/imag
ComplexNumber ComplexNumber::operator / (const ComplexNumber& arg)
{
    //code here
    ComplexNumber result = ComplexNumber();
    double abs_arg = (arg.get_realComponent() * arg.get_realComponent()) + (arg.get_imagComponent() * arg.get_imagComponent());
    result.set_realComponent((realComponent * arg.get_realComponent() + imagComponent * arg.get_imagComponent()) / abs_arg);
    result.set_imagComponent((imagComponent * arg.get_realComponent() - realComponent * arg.get_imagComponent()) / abs_arg);
    return result;
}

ComplexNumber ComplexNumber::operator + (const RealNumber& arg){
	return ComplexNumber(realComponent + arg.get_value(), imagComponent);
}

ComplexNumber ComplexNumber::operator - (const RealNumber& arg){
	return ComplexNumber(realComponent - arg.get_value(), imagComponent);
}

ComplexNumber ComplexNumber::operator * (const RealNumber& arg){
	return ComplexNumber(realComponent * arg.get_value(), imagComponent * arg.get_value());
}

ComplexNumber ComplexNumber::operator / (const RealNumber& arg){
	return ComplexNumber(realComponent / arg.get_value(), imagComponent / arg.get_value());
}

ComplexNumber ComplexNumber::operator + (const RationalNumber& arg){
	return ComplexNumber(realComponent + arg.decimal_value(), imagComponent);
}

ComplexNumber ComplexNumber::operator - (const RationalNumber& arg){
	return ComplexNumber(realComponent - arg.decimal_value(), imagComponent);
}

ComplexNumber ComplexNumber::operator * (const RationalNumber& arg){
	return ComplexNumber(realComponent * arg.decimal_value(), imagComponent * arg.decimal_value());
}

ComplexNumber ComplexNumber::operator / (const RationalNumber& arg){
	return ComplexNumber(realComponent / arg.decimal_value(), imagComponent / arg.decimal_value());
}

//to_String converts real and imaginary components to string of type a+bi
string ComplexNumber::to_String(void){
	stringstream my_output;
	my_output << realComponent;
	if(imagComponent >= 0){
		my_output << " + " << imagComponent << "i";
	}
	else if(imagComponent < 0){
		my_output << "-" << imagComponent*(-1) << "i";
	}
	return my_output.str();
}
