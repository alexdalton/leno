#include "RealNumber.h"

//constructors for real number
RealNumber::RealNumber()
{
    value = 0.0;
    NumberType = REAL;
}

RealNumber::RealNumber(double rval)
{
    value = rval;
    NumberType = REAL;
}

RealNumber::RealNumber( const RealNumber& other )
{
    value = other.get_value();
    NumberType = REAL;
}

//set the value for real number
void RealNumber::set_value (double rval)
{
    //code here
    value = rval;
}

//get the value for real number
double RealNumber::get_value(void) const
{
    return value;
}


//return the magnitiude of the real number
double RealNumber::magnitude()
{
    return abs(value);
}

//real + real
RealNumber RealNumber::operator + (const RealNumber& arg)
{
    //code here
    return RealNumber(value + arg.get_value());
}

//real - real
RealNumber RealNumber::operator - (const RealNumber& arg)
{
    //code here
    return RealNumber(value - arg.get_value());
}

//real * real
RealNumber RealNumber::operator * (const RealNumber& arg)
{
    //code here
    return RealNumber(value * arg.get_value());
}

//real/real
RealNumber RealNumber::operator / (const RealNumber& arg)
{
    //code here
    return RealNumber(value / arg.get_value());
}

ComplexNumber RealNumber::operator + (const ComplexNumber& arg){
	return ComplexNumber(value + arg.get_realComponent(), arg.get_imagComponent());
}
ComplexNumber RealNumber::operator - (const ComplexNumber& arg){
	return ComplexNumber(value - arg.get_realComponent(), (-1.0) * arg.get_imagComponent());
}
ComplexNumber RealNumber::operator * (const ComplexNumber& arg){
	return ComplexNumber(value * arg.get_realComponent(), value * arg.get_imagComponent());
}
ComplexNumber RealNumber::operator / (const ComplexNumber& arg){
	ComplexNumber result = ComplexNumber();
	double abs_arg = (arg.get_realComponent() * arg.get_realComponent()) + (arg.get_imagComponent() * arg.get_imagComponent());
	result.set_realComponent((value * arg.get_realComponent()) / abs_arg);
	result.set_imagComponent(((-1.0) * value * arg.get_imagComponent()) / abs_arg);
	return result;
}

RealNumber RealNumber::operator + (const RationalNumber& arg){
	return RealNumber(value + arg.decimal_value());
}
RealNumber RealNumber::operator - (const RationalNumber& arg){
	return RealNumber(value - arg.decimal_value());
}
RealNumber RealNumber::operator * (const RationalNumber& arg){
	return RealNumber(value * arg.decimal_value());
}
RealNumber RealNumber::operator / (const RationalNumber& arg){
	return RealNumber(value / arg.decimal_value());
}

//to_String converts real and imaginary components to string of type a+bi
string RealNumber::to_String(void){
	stringstream my_output;
	my_output << value;
	return my_output.str();
}

