#include "RationalNumber.h"

RationalNumber::RationalNumber()
{
	set_value(0, 1);
	NumberType = RATIONAL;
}

RationalNumber::RationalNumber(int numer, int denom)
{
	set_value(numer, denom);
	NumberType = RATIONAL;
}

RationalNumber::RationalNumber( const RationalNumber& other ){
	set_value(other.get_numerator(), other.get_denominator());
	NumberType = RATIONAL;
}

//Set the value of the numerator
//Should also maintain correct normalization
void RationalNumber::set_numerator(int numer){
	set_value (numer, denominator);
}

//Set the value of the denominator
//Should also maintain correct normalization
void RationalNumber::set_denominator(int denom){
	set_value (numerator, denom);
}

//Get the value of the numerator
int RationalNumber::get_numerator(void) const{
	return numerator;
}

//Get the value of the denominator
int RationalNumber::get_denominator(void) const{
	return denominator;
}

//set the complexnumber value
void RationalNumber::set_value (int numer, int denom)
{
    //code here
    int norm = gcd(numer, denom);
    int sign = ((numer < 0 && denom > 0) || (numer > 0 && denom < 0)) ? -1 : 1;
    
    numerator = sign * abs(numer) / norm;
    denominator = abs(denom) / norm;
}

//return the magnitude of the rational number
double RationalNumber::magnitude(){
    //code here
    return abs((double) numerator / (double) denominator);
}

//return the decimal value of the rational number
double RationalNumber::decimal_value() const{
    return (double) numerator / (double) denominator;
}

// helper function
int RationalNumber::gcd(int a, int b) {
    a = abs(a);
    b = abs(b);
    
    return (b == 0) ? a : gcd(b, a % b);
}

//imag + imag
RationalNumber RationalNumber::operator + (const RationalNumber& arg)
{
    int result_num = numerator * arg.get_denominator() + denominator * arg.get_numerator();
    int result_denom = denominator * arg.get_denominator();
    return RationalNumber(result_num, result_denom);
}

//imag - imag
RationalNumber RationalNumber::operator - (const RationalNumber& arg)
{
    //code here
    int result_num = numerator * arg.get_denominator() - denominator * arg.get_numerator();
    int result_denom = denominator * arg.get_denominator();
    return RationalNumber(result_num, result_denom);
}

//imag * imag
RationalNumber RationalNumber::operator * (const RationalNumber& arg)
{
    //code here
    int result_num = numerator * arg.get_numerator();
    int result_denom = denominator * arg.get_denominator();
    return RationalNumber(result_num, result_denom);
}

//imag/imag
RationalNumber RationalNumber::operator / (const RationalNumber& arg)
{
    //code here
    int result_num = numerator * arg.get_denominator();
    int result_denom = denominator * arg.get_numerator();
    return RationalNumber(result_num, result_denom);
}

ComplexNumber RationalNumber::operator + (const ComplexNumber& arg){
	return ComplexNumber(decimal_value() + arg.get_realComponent(), arg.get_imagComponent());
}
ComplexNumber RationalNumber::operator - (const ComplexNumber& arg){
	return ComplexNumber(decimal_value() - arg.get_realComponent(), (-1.0) * arg.get_imagComponent());
}
ComplexNumber RationalNumber::operator * (const ComplexNumber& arg){
	return ComplexNumber(decimal_value() * arg.get_realComponent(), decimal_value() * arg.get_imagComponent());
}
ComplexNumber RationalNumber::operator / (const ComplexNumber& arg){
	ComplexNumber result = ComplexNumber();
	double abs_arg = (arg.get_realComponent() * arg.get_realComponent()) + (arg.get_imagComponent() * arg.get_imagComponent());
	result.set_realComponent((decimal_value() * arg.get_realComponent()) / abs_arg);
	result.set_imagComponent(((-1.0) * decimal_value() * arg.get_imagComponent()) / abs_arg);
	return result;
}

RealNumber RationalNumber::operator + (const RealNumber& arg){
	return RealNumber(decimal_value() + arg.get_value());
}
RealNumber RationalNumber::operator - (const RealNumber& arg){
	return RealNumber(decimal_value() - arg.get_value());
}
RealNumber RationalNumber::operator * (const RealNumber& arg){
	return RealNumber(decimal_value() * arg.get_value());
}
RealNumber RationalNumber::operator / (const RealNumber& arg){
	return RealNumber(decimal_value() / arg.get_value());
}


//to_String converts numerator and denominator to string of type num/denom
string RationalNumber::to_String(void){
	stringstream my_output;
	my_output << numerator << "/" << denominator;
	return my_output.str();
}

